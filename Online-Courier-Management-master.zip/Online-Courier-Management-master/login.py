from tkinter import *
window=Tk()
log=tkinter.Intvar()
name=Entry(wnd,textvar=log,text="userid")
name.place(x=1,y=10)
window.mainloop()
